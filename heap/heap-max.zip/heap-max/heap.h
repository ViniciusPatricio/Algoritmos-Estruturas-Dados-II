#ifndef _HEAP_H_
#define _HEAP_H_

/* Exemplo de estrutura de dados para heap máxima.
 */


/* Protótipo para a única função que precisa estar acessível para o usuário,
 * isto é, a construção da heap.
 */
void montar_heap(int *vet, int tam);

#endif
